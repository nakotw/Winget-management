# Easy Download
To download this part of the repository, click on the **ZIP-file** and use the Download-Button.

> All blogposts from my blog, you'll find at https://scloud.work/en/